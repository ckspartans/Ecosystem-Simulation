import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AbsOrganism here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class AbsOrganism extends Actor
{
    int age;//grow, die
    int speed;//track, move
    int spX;
    int spY;
    int foodEaten;
    int energy;//die, eat
    int size;//eat, die(decompose), attack
    int diet;//(herbivore, omnivore, carnivore(scavenger)) - eat
    int gene;//every creature starts with a different gene, once they have enough energy they mutate to a higher version of their gene
    boolean cannibalism;//eat
    int range;
    int lifeStage;
    /**
     * Act - do whatever the AbsOrganism wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    public abstract void grow(int age, int size, int lifeStage);
    public abstract void age(int age, int lifeStage);
    public abstract void die(int age, int energy, int size);//decompose - when energy = 0 size decreases
    public abstract void move(int speed, int spX, int spY, int energy);
    public abstract void spawn(int gene);
    public abstract void mutate(int gene);
    public abstract void eat(int energy, int foodEaten);
    public abstract void track(int speed, int energy, int range, int diet, boolean cannibalism);//speed increase if tracking, energy decreases faster(smaller range than prey)
    public abstract void interact(int size);
    public abstract void attack(int size);
    public abstract void flee(int speed, int spX, int spY, int range);//speed increase if tracking, energy decreases faster(larger range than predator)
    public abstract void excrete();
    
}



