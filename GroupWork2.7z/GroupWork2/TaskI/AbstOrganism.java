import greenfoot.*; // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
* Write a description of class AbstOrgansim here.
* 
* @author (your name) 
* @version (a version number or a date)
*/

public abstract class AbstOrganism extends Actor
{
    
    MyWorld world;
    GreenfootImage image;
    static protected ArrayList <AbstOrganism> lifeforms = new ArrayList <AbstOrganism> ();//list of all the organsims in the game
    protected ArrayList <AbstOrganism> prey;//list of all that the types of organism can feed on
    protected ArrayList <AbstOrganism> predators;//list of all the types of organsims that the organism can be eaten by 
    protected int trophic_Level;
    protected int age;
    protected int split_Energy;
    protected int siz;
    protected GreenfootImage [] imgs;
    protected double health;
    protected double energy;
    protected double speed;
    protected int att;
    protected int def;
    protected double mutation_Rate;
    
    protected abstract void feed();
    
    protected abstract void grow();
    
    protected abstract void split();
    
    protected abstract void age();
    
    protected abstract void die();
    
    protected abstract void move();
    
    protected abstract void mutate(); 
    
    protected void say (String phrase) {
    
        System.out.println(phrase);
        
    }

}