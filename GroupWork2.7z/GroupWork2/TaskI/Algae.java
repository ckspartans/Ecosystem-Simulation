import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Write a description of class Algae here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Algae extends AbstOrganism
{
    /**
     * Act - do whatever the Algae wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    // Base Constructor
    public Algae () {

        //lifeforms = new ArrayList <AbstOrganism> ();//list of all the organsims in the game
        lifeforms.add(this);
        prey = new ArrayList <AbstOrganism> ();//list of all that the types of organism can feed on
        predators = new ArrayList <AbstOrganism> ();//list of all the types of organsims that the organism can be eaten by 
        trophic_Level = 0; // The trophic level of the organism, its place in the food web / chain
        age = 0;
        split_Energy = 15;
        siz = (int) (0.2 * energy + 5);
        // Later GreenfootImage [] imgs;
        health = 100;
        energy = 0;
        speed = 0;
        att = 0;
        def = 0;
        mutation_Rate = 0.00;
    
    }
    
    public void act() 
    {
        
        // Add your action code here.\
        // If the world reference is not stored:
        if (world == null) {
        
            world = (MyWorld) getWorld (); // Store the reference to the current world
        
        }
        
        // If the object's image is not stored:
        if (image == null) {
        
            image = getImage(); // Store the reference to the current image
        
        }
        
        age ();
        feed ();
        grow ();
        split ();
        
        
    }
    
    protected void feed() {
        
        // Increases the energy amount.
        energy += 0.001;
        //world.showText("Energy: " + energy, getX(), getY());
        // Possible TODO: Account for amount of overlap between organism
        
        //say ("feed not implemented");
    
    }
    
    protected void grow() {
        
        // Modify the size of the image based on  the current energy
        siz = (int) (0.2 * energy + 5);
        image.scale(siz, siz);
        GreenfootImage img = new GreenfootImage (siz, siz);
        
        //say ("grow not implemented");
    
    }
    
    protected void split(){
        
        int num_Split = 5;
        int angle = 360 / num_Split;
        
        // Check to see if there if enough energy (size?) to split
        if (energy >= split_Energy) {
        
            // If yes, then call the constructor for two new ones and kill the parent
            energy -= split_Energy; // Subtract the used up energy needed to split.
            
            // A for loop running once for each num_Split (child to be made)
            for (int i = 0; i < num_Split; i ++) {
            
                Algae temp_Splited = new Algae ();

                //lifeforms.add(new Algae());
                world.addObject(temp_Splited, getX(), getY());
                
                temp_Splited.turn (angle * i);
                temp_Splited.move(5);
            
            }
            
            die();
            
        }
        
        //say ("split not implemented");
    
    }
    
    protected void age() {
        
        // Increases age
        age ++;
        // Checks to see if past lifespan
            // If so, kill the organism
        //say ("age not implemented");
    
    }
    
    protected void die() {
        
        // Remove this object from its lists
        lifeforms.remove(this);
        // Remove from the world
        world.removeObject(this);
        //say ("die not implemented");
    
    }
    
    protected void move() {
    
        say ("Move not implemented");
    
    }
    
    protected void mutate() {
    
        say ("Mutate not implemented");
    
    }
    
}
